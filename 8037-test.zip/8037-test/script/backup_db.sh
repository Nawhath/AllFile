#!/bin/bash
NOW=$(date +"%Y-%m-%d_%H-%M")
PORT="8037"
FILE="/var/dockers/$PORT/backup/DB-$PORT-$db-$NOW.sql.gz"
rm -f /var/dockers/$PORT/backup/DB-*

databases=`docker exec 8037_mysql mysql -uappteam -papp2010 -e "SHOW DATABASES;" | grep -Ev "(Database|information_schema|performance_schema|mysql|sys)"`

for db in $databases; do
        docker exec 8037_mysql mysqldump --force --opt -uappteam -papp2010 --databases $db | gzip > /var/dockers/$PORT/backup/DB-$PORT-$db-$(date +%Y-%m-%d_%H-%M).sql.gz
done
