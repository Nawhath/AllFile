#!/bin/bash
NOW=$(date +"%Y-%m-%d_%H-%M")
PORT="8037"
PATHX="/var/dockers/$PORT"
SOURCE="$PATHX/www"
FILE="$PATHX/backup/www-$PORT-$NOW.tar.gz"
rm -f $PATHX/backup/www-*
rm -f /var/dockers/script/logs/$PORT-backup_www_successful
tar --ignore-failed-read -cvzf $FILE $SOURCE >/dev/null 2>&1
