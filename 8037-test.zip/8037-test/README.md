App VCATE
Start docker-compose by porttainer
Access http://192.168.1.71:9000
Build image by portainer gui
Path Dockerfile= ./apache2/Dockerfile
